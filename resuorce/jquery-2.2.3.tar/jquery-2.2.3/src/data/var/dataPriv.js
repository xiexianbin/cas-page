define( [
	"../Data"
], function( Data ) {
	return new Data();
} );
